//
//  ViewController.swift
//  Takkellapati_GroceryApp
//
//  Created by Takkellapati,Venkata Prabhakar on 4/5/22.
//

import UIKit

class GrocerySectionsViewController: UIViewController {

   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

