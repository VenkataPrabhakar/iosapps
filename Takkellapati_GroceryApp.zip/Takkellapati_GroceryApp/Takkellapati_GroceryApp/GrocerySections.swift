//
//  GrocerySections.swift
//  Takkellapati_GroceryApp
//
//  Created by Takkellapati,Venkata Prabhakar on 4/5/22.
//

import Foundation
struct GrocerySections{
    var section = ""
    var items:[GroceryItem] = []
    
}
struct GroceryItem {
    var itemName = ""
    var itemInfo = ""
    
}
