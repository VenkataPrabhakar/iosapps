//
//  RootVC.swift
//  Atmakuri_NavigationApp
//
//  Created by student on 4/5/22.
//

import UIKit

class RootVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.Password.isEnabled = false
        self.Login.isEnabled = false

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var Password: UITextField!
    
    @IBOutlet weak var Username: UITextField!
    
    @IBOutlet weak var Login: UIButton!
    
    @IBAction func PasswordEnable(_ sender: UITextField) {
        if(self.Username.text == "admin"){
            self.Password.isEnabled = true
        }
    }
    
    @IBAction func LoginBTNEnable(_ sender: UITextField) {
        if(self.Password.text == "password" && self.Username.text == "admin"){
            self.Login.isEnabled = true
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
