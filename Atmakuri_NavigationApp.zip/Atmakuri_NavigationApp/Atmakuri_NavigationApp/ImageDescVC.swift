//
//  ImageDescVC.swift
//  Atmakuri_NavigationApp
//
//  Created by student on 4/5/22.
//

import UIKit

class ImageDescVC: UIViewController {
    var imgval = ""
    var desc = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        self.imageOT.image = UIImage(named: imgval)
        self.Descr.text = desc
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var imageOT: UIImageView!
    
    
    @IBOutlet weak var Descr: UILabel!
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
