//
//  ViewController.swift
//  Atmakuri_NavigationApp
//
//  Created by student on 4/5/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

