//
//  WelcomeVc.swift

//  Project_MileStone02
//  Created by student on 4/13/22.
//

import UIKit

class WelcomeVc: UIViewController {

    @IBOutlet var txtViewDescription: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()

    }
}

