//
//  FormArray.swift
//  Project_MileStone02
//  Created by student on 4/13/22.

//

import Foundation

var arrayTravelForm = [[String]]()
var arrayShoppingForm = [[String]]()
var arrayMedicationForm = [[String]]()
var arrayOtherForm = [[String]]()
